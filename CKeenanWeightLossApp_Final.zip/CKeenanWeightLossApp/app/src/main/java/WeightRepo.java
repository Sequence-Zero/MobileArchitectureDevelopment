package com.zybooks.ckeenanweightlossapp;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class WeightRepo {
    private final AppDb helper;
    public WeightRepo(Context c) { helper = new AppDb(c); }

    public long insert(long userId, String dateIso, double weight) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("date", dateIso);
        cv.put("weight", weight);
        return db.insert(AppDb.T_WEIGHTS, null, cv);
    }

    public int delete(long id) {
        return helper.getWritableDatabase()
                .delete(AppDb.T_WEIGHTS, "id=?", new String[]{ String.valueOf(id) });
    }

    public int update(long id, double newWeight) {
        ContentValues cv = new ContentValues();
        cv.put("weight", newWeight);
        return helper.getWritableDatabase()
                .update(AppDb.T_WEIGHTS, cv, "id=?", new String[]{ String.valueOf(id) });
    }

    public static class Row {
        public final long id; public final String date; public final double weight;
        public Row(long id, String date, double weight) { this.id=id; this.date=date; this.weight=weight; }
    }

    public List<Row> listForUser(long userId) {
        ArrayList<Row> list = new ArrayList<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT id,date,weight FROM " + AppDb.T_WEIGHTS + " WHERE user_id=? ORDER BY date DESC",
                new String[]{ String.valueOf(userId) })) {
            while (c.moveToNext()) list.add(new Row(c.getLong(0), c.getString(1), c.getDouble(2)));
        }
        return list;
    }

    public Double latestWeight(long userId) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT weight FROM " + AppDb.T_WEIGHTS + " WHERE user_id=? ORDER BY date DESC LIMIT 1",
                new String[]{ String.valueOf(userId) })) {
            return c.moveToFirst() ? c.getDouble(0) : null;
        }
    }
}