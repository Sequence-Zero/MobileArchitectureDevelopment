package com.zybooks.ckeenanweightlossapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDb extends SQLiteOpenHelper {

    public static final String DB_NAME = "weight_tracker.db";
    public static final int DB_VERSION = 1;

    public static final String T_USERS   = "users";
    public static final String T_WEIGHTS = "weights";
    public static final String T_GOALS   = "goals";

    public AppDb(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "email TEXT UNIQUE NOT NULL," +
                "password TEXT NOT NULL" +
                ");");

        db.execSQL("CREATE TABLE " + T_WEIGHTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER NOT NULL," +
                "date TEXT NOT NULL," +
                "weight REAL NOT NULL," +
                "FOREIGN KEY(user_id) REFERENCES " + T_USERS + "(id) ON DELETE CASCADE" +
                ");");

        db.execSQL("CREATE TABLE " + T_GOALS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id INTEGER UNIQUE NOT NULL," + // one goal per user
                "goal REAL NOT NULL," +
                "direction TEXT NOT NULL," +         // 'Lose' or 'Gain'
                "FOREIGN KEY(user_id) REFERENCES " + T_USERS + "(id) ON DELETE CASCADE" +
                ");");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + T_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }
}
