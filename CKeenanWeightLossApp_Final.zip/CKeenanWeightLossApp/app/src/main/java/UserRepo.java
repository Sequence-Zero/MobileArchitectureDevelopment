package com.zybooks.ckeenanweightlossapp;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserRepo {
    private final AppDb helper;
    public UserRepo(Context c) { helper = new AppDb(c); }

    public long createUser(String email, String password) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("email", email.trim().toLowerCase());
        cv.put("password", password); // TODO: hash in a real app
        return db.insertOrThrow(AppDb.T_USERS, null, cv);
    }

    public long getUserIdIfValid(String email, String password) {
        SQLiteDatabase db = helper.getReadableDatabase();
        String[] args = { email.trim().toLowerCase(), password };
        try (Cursor c = db.rawQuery(
                "SELECT id FROM " + AppDb.T_USERS + " WHERE email=? AND password=?",
                args)) {
            if (c.moveToFirst()) return c.getLong(0);
            return -1;
        }
    }
}