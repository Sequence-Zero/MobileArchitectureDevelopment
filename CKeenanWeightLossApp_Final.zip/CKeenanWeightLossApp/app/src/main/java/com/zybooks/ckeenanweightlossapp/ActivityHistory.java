package com.zybooks.ckeenanweightlossapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.zybooks.ckeenanweightlossapp.me.R;
import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    private long userId;
    private WeightRepo repo;
    private HistoryAdapter adapter;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_history);
        userId = getIntent().getLongExtra("USER_ID", -1);
        repo = new WeightRepo(this);

        RecyclerView rv = findViewById(R.id.rvHistory);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new HistoryAdapter(repo.listForUser(userId), repo, () -> {
            adapter.setData(repo.listForUser(userId));
        });
        rv.setAdapter(adapter);
    }

    static class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.VH> {
        private List<WeightRepo.Row> data;
        private final WeightRepo repo;
        private final Runnable onChanged;
        HistoryAdapter(List<WeightRepo.Row> d, WeightRepo r, Runnable onChanged) { data=d; repo=r; this.onChanged=onChanged; }
        void setData(List<WeightRepo.Row> d){ data=d; notifyDataSetChanged(); }

        static class VH extends RecyclerView.ViewHolder {
            TextView date, weight; Button delete;
            VH(View v){ super(v); date=v.findViewById(R.id.tvDate); weight=v.findViewById(R.id.tvWeight); delete=v.findViewById(R.id.btnDeleteRow); }
        }
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int t){
            View v = LayoutInflater.from(p.getContext()).inflate(R.layout.item_history_row, p, false);
            return new VH(v);
        }
        @Override public void onBindViewHolder(@NonNull VH h, int i){
            WeightRepo.Row row = data.get(i);
            h.date.setText(row.date);
            h.weight.setText(String.format("%.1f", row.weight));
            h.delete.setOnClickListener(v -> { repo.delete(row.id); onChanged.run(); });
        }
        @Override public int getItemCount(){ return data.size(); }
    }
}