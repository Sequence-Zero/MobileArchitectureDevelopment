package com.zybooks.ckeenanweightlossapp;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText etEmail, etPassword;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        Button btnSignIn = findViewById(R.id.btnSignIn);
        Button btnCreate = findViewById(R.id.btnCreate);

        btnSignIn.setOnClickListener(v -> {
            if (validate()) {

                startActivity(new Intent(this, DashboardActivity.class));
            }
        });

        btnCreate.setOnClickListener(v -> {
            if (validate()) {

                Toast.makeText(this, "Account created (placeholder).", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, DashboardActivity.class));
            }
        });
    }

    private boolean validate() {
        boolean ok = true;
        if (TextUtils.isEmpty(etEmail.getText())) { etEmail.setError("Required"); ok = false; }
        if (TextUtils.isEmpty(etPassword.getText()) || etPassword.length() < 6) {
            etPassword.setError("Min 6 chars"); ok = false;
        }
        return ok;
    }
}