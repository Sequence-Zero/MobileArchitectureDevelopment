package com.zybooks.ckeenanweightlossapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.ckeenanweightlossapp.R;
import com.zybooks.ckeenanweightlossapp.data.GoalRepo;

public class SetGoalActivity extends AppCompatActivity {
    private long userId;
    private GoalRepo goals;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_set_goal);

        userId = getIntent().getLongExtra("USER_ID", -1);
        goals  = new GoalRepo(this);

        EditText etGoal = findViewById(R.id.etGoal);
        RadioGroup rg    = findViewById(R.id.rgDirection);
        Button save      = findViewById(R.id.btnSaveGoal);

        save.setOnClickListener(v -> {
            if (TextUtils.isEmpty(etGoal.getText()) || rg.getCheckedRadioButtonId() == -1) {
                Toast.makeText(this,"Enter goal and choose direction",Toast.LENGTH_SHORT).show();
                return;
            }
            double g = Double.parseDouble(etGoal.getText().toString());
            String dir = ((RadioButton)findViewById(rg.getCheckedRadioButtonId())).getText().toString();
            goals.upsert(userId, g, dir);
            Toast.makeText(this,"Goal saved",Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}