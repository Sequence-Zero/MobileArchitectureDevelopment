package com.zybooks.ckeenanweightlossapp;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.ckeenanweightlossapp.R;

public class AddWeightActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_add_weight);

        EditText etWeight = findViewById(R.id.etWeight);
        EditText etDate = findViewById(R.id.etDate);
        etDate.setText("Today"); // placeholder

        Button btn = findViewById(R.id.btnSaveWeight);
        btn.setOnClickListener(v -> {
            if (TextUtils.isEmpty(etWeight.getText())) {
                etWeight.setError("Required");
                return;
            }
            Toast.makeText(this, "Saved (placeholder).", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}