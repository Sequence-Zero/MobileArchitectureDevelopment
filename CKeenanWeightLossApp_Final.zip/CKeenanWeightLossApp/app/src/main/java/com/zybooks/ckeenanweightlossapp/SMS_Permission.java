package com.zybooks.ckeenanweightlossapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.zybooks.ckeenanweightlossapp.me.R;

public class SmsPermissionActivity extends AppCompatActivity {
    private TextView tv;

    private final ActivityResultLauncher<String> launcher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    granted -> tv.setText("SMS Permission: " + (granted ? "Granted" : "Denied")));

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_sms_permission);
        tv = findViewById(R.id.tvSmsStatus);
        Button btnRequest = findViewById(R.id.btnRequestSms);
        Button btnSend    = findViewById(R.id.btnSendTest);

        btnRequest.setOnClickListener(v -> launcher.launch(Manifest.permission.SEND_SMS));

        btnSend.setOnClickListener(v -> {
            boolean allowed = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED;
            if (!allowed) {
                tv.setText("SMS Permission: Denied (app continues without SMS)");
                return; // ← per requirements, rest of app keeps working
            }
            // “Happy path”: send a simple SMS (use emulator ‘Phone’ to see it)
            try {
                SmsManager.getDefault().sendTextMessage(
                        "5556", null, "Weight Tracker: Goal reached!", null, null);
                tv.setText("SMS Permission: Granted (test SMS sent)");
            } catch (Exception e) {
                tv.setText("SMS error: " + e.getMessage());
            }
        });
    }
}