package com.zybooks.ckeenanweightlossapp;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.ckeenanweightlossapp.R;
import com.zybooks.ckeenanweightlossapp.data.*;

public class DashboardActivity extends AppCompatActivity {
    private long userId;
    private WeightRepo weights;
    private GoalRepo goals;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_dashboard);

        userId  = getIntent().getLongExtra("USER_ID", -1);
        weights = new WeightRepo(this);
        goals   = new GoalRepo(this);

        TextView tv = findViewById(R.id.tvSummary);
        updateSummary(tv);

        findViewById(R.id.btnAddWeight).setOnClickListener(v -> {
            Intent i = new Intent(this, AddWeightActivity.class);
            i.putExtra("USER_ID", userId);
            startActivity(i);
        });
        findViewById(R.id.btnSetGoal).setOnClickListener(v -> {
            Intent i = new Intent(this, SetGoalActivity.class);
            i.putExtra("USER_ID", userId);
            startActivity(i);
        });
        findViewById(R.id.btnHistory).setOnClickListener(v -> {
            Intent i = new Intent(this, HistoryActivity.class);
            i.putExtra("USER_ID", userId);
            startActivity(i);
        });
        findViewById(R.id.btnSms).setOnClickListener(v ->
                startActivity(new Intent(this, SmsPermissionActivity.class)));
    }

    @Override protected void onResume() {
        super.onResume();
        updateSummary((TextView) findViewById(R.id.tvSummary));
    }

    private void updateSummary(TextView tv) {
        Double latest = weights.latestWeight(userId);
        GoalRepo.Goal g = goals.get(userId);
        String text = "Latest: " + (latest==null? "—" : String.format("%.1f", latest));
        text += "   Goal: " + (g==null? "—" : String.format("%.1f (%s)", g.goal, g.dir));
        if (latest != null && g != null) {
            double delta = "Lose".equals(g.dir) ? latest - g.goal : g.goal - latest;
            text += "   Δ: " + String.format("%.1f", delta);
        } else {
            text += "   Δ: —";
        }
        tv.setText(text);
    }
}