package com.zybooks.ckeenanweightlossapp;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.time.LocalDate;
import com.zybooks.ckeenanweightlossapp.R;
import com.zybooks.ckeenanweightlossapp.data.*;

public class AddWeightActivity extends AppCompatActivity {
    private long userId;
    private WeightRepo weights;
    private GoalRepo goals;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_add_weight);

        userId  = getIntent().getLongExtra("USER_ID", -1);
        weights = new WeightRepo(this);
        goals   = new GoalRepo(this);

        EditText etWeight = findViewById(R.id.etWeight);
        EditText etDate   = findViewById(R.id.etDate);
        etDate.setText(LocalDate.now().toString()); // yyyy-MM-dd

        Button save = findViewById(R.id.btnSaveWeight);
        save.setOnClickListener(v -> {
            if (TextUtils.isEmpty(etWeight.getText())) {
                etWeight.setError("Required"); return;
            }
            double w = Double.parseDouble(etWeight.getText().toString());
            String d = etDate.getText().toString();
            weights.insert(userId, d, w);

            // After insert, evaluate goal. If met, we will delegate to SmsPermissionActivity (optional).
            GoalRepo.Goal g = goals.get(userId);
            if (g != null) {
                boolean met = "Lose".equals(g.dir) ? w <= g.goal : w >= g.goal;
                if (met) Toast.makeText(this, "Goal reached! (notify user)", Toast.LENGTH_LONG).show();
                // You could also start SmsPermissionActivity here to request/send SMS.
            }

            finish();
        });
    }
}