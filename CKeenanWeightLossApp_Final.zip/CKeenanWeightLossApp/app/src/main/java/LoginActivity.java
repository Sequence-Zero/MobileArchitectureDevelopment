package com.zybooks.ckeenanweightlossapp;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import your.package.name.R;
import your.package.name.data.UserRepo;

public class LoginActivity extends AppCompatActivity {
    private UserRepo users;
    private long currentUserId = -1;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        users = new UserRepo(this);

        EditText email = findViewById(R.id.etEmail);
        EditText pass  = findViewById(R.id.etPassword);
        Button signIn  = findViewById(R.id.btnSignIn);
        Button create  = findViewById(R.id.btnCreate);

        signIn.setOnClickListener(v -> {
            if (!validate(email, pass)) return;
            long id = users.getUserIdIfValid(email.getText().toString(), pass.getText().toString());
            if (id > 0) {
                currentUserId = id;
                startDashboard();
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        create.setOnClickListener(v -> {
            if (!validate(email, pass)) return;
            try {
                long id = users.createUser(email.getText().toString(), pass.getText().toString());
                currentUserId = id;
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
                startDashboard();
            } catch (Exception e) {
                Toast.makeText(this, "User exists or invalid input", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validate(EditText email, EditText pass) {
        boolean ok = true;
        if (TextUtils.isEmpty(email.getText()) || !email.getText().toString().contains("@")) {
            email.setError("Valid email required"); ok=false;
        }
        if (TextUtils.isEmpty(pass.getText()) || pass.length() < 6) {
            pass.setError("Min 6 chars"); ok=false;
        }
        return ok;
    }

    private void startDashboard() {
        Intent i = new Intent(this, DashboardActivity.class);
        i.putExtra("USER_ID", currentUserId);
        startActivity(i);
        finish();
    }
}
