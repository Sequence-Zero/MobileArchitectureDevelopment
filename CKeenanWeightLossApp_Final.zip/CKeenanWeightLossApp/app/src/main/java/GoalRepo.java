package com.zybooks.ckeenanweightlossapp;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class GoalRepo {
    private final AppDb helper;
    public GoalRepo(Context c) { helper = new AppDb(c); }

    public void upsert(long userId, double goal, String direction) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("user_id", userId);
        cv.put("goal", goal);
        cv.put("direction", direction);
        // try update
        int n = db.update(AppDb.T_GOALS, cv, "user_id=?", new String[]{ String.valueOf(userId) });
        if (n == 0) db.insert(AppDb.T_GOALS, null, cv);
    }

    public static class Goal { public final double goal; public final String dir;
        public Goal(double g, String d){ goal=g; dir=d; } }

    public Goal get(long userId) {
        SQLiteDatabase db = helper.getReadableDatabase();
        try (Cursor c = db.rawQuery(
                "SELECT goal,direction FROM " + AppDb.T_GOALS + " WHERE user_id=?",
                new String[]{ String.valueOf(userId) })) {
            if (c.moveToFirst()) return new Goal(c.getDouble(0), c.getString(1));
            return null;
        }
    }
}